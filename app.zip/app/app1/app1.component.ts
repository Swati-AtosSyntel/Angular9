import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl, Validators} from  '@angular/forms';

@Component({
  selector: 'app-app1',
  templateUrl: './app1.component.html',
  styleUrls: ['./app1.component.css']
})
export class App1Component implements OnInit {
  email;
  formdata;
  constructor() { }

  ngOnInit(): void {
    this.formdata=new FormGroup({
      email:new FormControl("angular9@gmail.com",Validators.compose([Validators.required,
        Validators.pattern("[^@]*@[^@]*")])),
      password:new FormControl("xyz@123",this.passwordvalidation)
    });

  
  }
  passwordvalidation(formcontrol){
    if(formcontrol.value.length<5){
      return {"password":true};
    }
  }
  onClickSubmit(data)
  {
    this.email=data.email;

  }



}
