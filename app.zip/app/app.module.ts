import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee/employee.component';
import { GenderPipe } from './employee/gender.pipe';
import { EmployeeListComponent } from './employee/employee-list/employee-list.component';
import { EmployeeCountComponent } from './employee/employee-list/employee-count/employee-count.component';
import { App1Component } from './app1/app1.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    GenderPipe,
    EmployeeListComponent,
    EmployeeCountComponent,
    App1Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
