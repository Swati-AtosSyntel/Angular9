import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  @Input()
  Male:number;
  @Input()
  Female:number;
  @Input()
  All:number;

  selectedRadioButtonValue:string;//keeps track of radio button selected

  @Output()
  countRadioButtonSelectionChanged:EventEmitter<string>=new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

  onRadioButtonSelectionChange(){
    this.countRadioButtonSelectionChanged.emit(this.selectedRadioButtonValue);//raises the custom event and passess the value of radio button selected
    console.log(this.selectedRadioButtonValue);
}

}
