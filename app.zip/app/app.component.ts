import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myAngularApp';
  isSelected:boolean=false;
show:true;
  colors=["Red","Green","Blue"];

  onClickSubmit(data){
    alert("Entered Email ID:"+data.email);
  }
}
