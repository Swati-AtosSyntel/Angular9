import {Component} from '@angular/core';

@Component({
    selector:'app-emp',
    templateUrl:'employee.component.html'

})
export class EmployeeComponent
{
    firstName:string='Ashwin';
    lastName:string="Agrawal";
    gender:string="Male";
    age:number=20;
    projects=["Fedex","VW"];
    day=1;
}