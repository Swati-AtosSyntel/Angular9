export interface IEmployee{
    id:number;
    name:string;
    salary:number;
    city:string;
    age:number;
    gender:number;
    dob:Date;
    pan:string;
    mobile:string;
}